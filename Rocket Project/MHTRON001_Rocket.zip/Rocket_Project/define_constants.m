% the rocket's dimensions, and offset from center of mass to geometric
% center
WIDTH = 5;
HEIGHT = 15;
OFFSET = 4;

%
MASS = 1000;

% the area where the action happens, for plotting purposes
XMIN = -3000;
XMAX =  3000;
YMIN =  0;
YMAX =  100000;
